<?php

include CTRLS . $controller . '/' . $view . '.php';

// include VIEWS . $controller . '/' . $view . '.php';
ob_start();
if(is_file(VIEWS . $controller . '/' . $view . '.html')){
	require VIEWS . $controller . '/' . $view . '.html';
} else {
	echo "<p>не найден вид <b>" . VIEWS . $controller . '/' . $view . ".html</b></p>";
}
$content = ob_get_clean();
$style = `<link rel="stylesheet" href="../css/core.css">`;
include VIEWS . "layout/default.html";