<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">

    <title>Главная страница</title>
    <style>
    	div {
    		border: 10px solid green;
    		padding: 5px;
    	}
    	.current_day {
			border: 5px solid yellow;
			padding: 5px;
			margin: 5px;
		}
		.holly_day {
			border: 5px solid red;
			padding: 5px;
			margin: 5px;
		}
	
	</style>

</head>

<body>
    <div class="container-fluide">
        <h1 class="text-center">Главная страница</h1>
        <div class="container-fluide">
			<div style="border: 10px solid red; padding: 15px"><?php echo date("Y-m-d")?>-08</div>
			<div style="border: 10px solid red; padding: 15px"><?php echo time()?></div>
			<div style="border: 10px solid red; padding: 15px"><?php echo ($nextWeek-$prevWeek)/(24*60*60)?></div> <?php
				$prevWeek = time() - (24 * 24 * 60 * 60);
				$nextWeek = time() + (249 * 24 * 60 * 60);
				// echo 'Предыдущая неделя: '. date('Y-m-d', $prevWeek) ."\n";

				$day = date("Y-m-d");

				for ($i=0; $i < ($nextWeek-$prevWeek)/(24*60*60); $i++) {
					$day1 = date('Y-m-d', ($prevWeek)+($i*24*60*60));
					if($day == $day1) {
						echo '<div style="border: 5px solid yellow; padding: 5px; margin: 5px" id="day">' . $day1 . '</div>';
					} elseif($day1 == '2021-10-05') {
						echo '<div style="border: 5px solid green; padding: 5px; margin: 10px" id="day">' . $day1 . '</div>';
					} else {
						echo '<div style="border: 10px solid blue; padding: 5px">' . $day1 . '</div>';
					}
				}
					?>     

	
        	
        </div>
    </div>


    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: jQuery and Bootstrap Bundle (includes Popper) -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-ygbV9kiqUc6oa4msXn9868pTtWMgiQaeYH7/t7LECLbyPA2x65Kgf80OJFdroafW" crossorigin="anonymous"></script>

</body>

</html>