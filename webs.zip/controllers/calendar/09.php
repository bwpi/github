<?php

$var = json_decode(file_get_contents(ROOT . '/files/develop.json'),true);
$var1 = json_decode(file_get_contents(ROOT . '/files/hb.json'),true);
// debug($var['2021-11-04']['name1']);
// debug($var1);
if (array_key_exists('2021-11-04', $var)){
   print_r($var["2021-11-04"]);
}
?>
<!doctype html>
<html lang="ru">
  <head>
    <!-- Обязательные метатеги -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-F3w7mX95PdgyTmZZMECAngseQB83DfGTowi0iMjiWaeVhAn4FJkqJByhZMI3AhiU" crossorigin="anonymous">

    <title>Привет мир!</title>
    <style>
    	div {
    		border: 10px solid blue;
    		padding: 5px;
    	}
    	.current_day {
			border: 5px solid yellow;
			padding: 5px;
			margin: 5px;
		}
		.holly_day {
			border: 5px solid red;
			padding: 5px;
			margin: 5px;
		}
		.time {
			background-color: #d2d2d2;
		}
		.time0 {
			background-color: #aaa;
		}
		.time1 {
			background-color: #000;
		}
		.develop {
			background-color: blue;
		}

    </style>
  </head>
  <body>
    <h1>Привет мир!</h1>
    <div class="<?=$time?>">

    	<?php
	$prevWeek = strtotime(date('2021-09-01'));	
	$nextWeek = strtotime(date('2022-05-31'));
	$day = date("Y-m-d");
	$t = date("H");
	if($t == '09') {
		$time = 'time0';
	} elseif ($t < '09') {
		$time = 'time1';
	} else {
		$time = 'time';
	}
?>
		<div style="border: 10px solid red; padding: 15px"><?php echo date("Y-m-d")?>-09</div>
		<div style="border: 10px solid red; padding: 15px"><?php echo time()?></div>
		<div style="border: 10px solid red; padding: 15px"><?php echo ($nextWeek-$prevWeek)/(24*60*60)?></div>

 	<?php for ($i=0; $i < ($nextWeek-$prevWeek)/(24*60*60); $i++) {
		$day1 = date('Y-m-d', ($prevWeek)+($i*24*60*60));
		if($day == $day1) { ?>
			<div class="current_day" id="day"><?=$day1?></div>
		<?php } elseif($day1 == '2021-10-05') { ?>
			<div class="holly_day"><?=$day1?></div>
		<?php } elseif(array_key_exists($day1, $var)) { ?>
			<div class="develop"><?=$day1?>
				<?php echo $var[$day1]['name1']?>
				<?php echo $var[$day1]['name2']?>
				<?php echo $var[$day1]['name3']?>
			</div>
		<?php } else { ?>
			<div><?=$day1?></div>
		<?php }	
		}
	?>
	</div>
    <!-- Дополнительный JavaScript; выберите один из двух! -->

    <!-- Вариант 1: Bootstrap в связке с Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-/bQdsTh/da6pkI1MST/rWKFNjaCP5gBSY4sEBT38Q/9RBh9AH40zEOg7Hlq2THRZ" crossorigin="anonymous"></script>

    <!-- Вариант 2: Bootstrap JS отдельно от Popper
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js" integrity="sha384-W8fXfP3gkOKtndU4JGtKDvXbO53Wy8SZCQHczT5FMiiqmQfUpWbYdTil/SxwZgAN" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.min.js" integrity="sha384-skAcpIdS7UcVUC05LJ9Dxay8AXcDYfBJqt1CJ85S/CFujBsIzCIv+l9liuYLaMQ/" crossorigin="anonymous"></script>
    -->
  </body>
</html>