<?php
/*
* Загрузка модели
*/
include (MODELS . 'model.php');
/*
*Переменные
*/
$title = 'Расписание';
$author = 'Учитель';
$out_array = [];
$day_array = [];
/*
*Ядро нашей программы
*/
$files = dirScan();
$out = sortJsonFiles(sortDataType($files, 'likes','editable'));

if (isset($_GET['id'])) {
	$id = FILES . $_GET['id'];
	$cls = $_GET['id'];
} elseif (isset($param)) {
	$id = FILES . $param;
	$cls = $param;
} else {	
	$id = FILES . '5';
	$cls = '5';
}

$schedule = readData($id . '.json');

foreach ($schedule as $key => $value) {	
	foreach ($value as $key1 => $value1) {
		array_push($day_array, $key1);
	}
}
$shedule_head = $controller . "/" . $view . '_head';
$shedule_view = $controller . "/" . $view;
/*
* Подключение персонального контроллера
*/
include CTRLS . $controller . '/' . $view . '.php';
/*
*Подключение шаблона
*/
include VIEWS . $controller . ".php";