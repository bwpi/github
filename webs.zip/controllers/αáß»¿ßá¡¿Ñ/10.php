<?php
/*
*Переменные
*/
$title = 'Расписание';
$nameout = 'Кайдаулов';
$author = 'Кайдаулов';
$color = getColor('00bfff');
$Email = 'Geniosar1@mail.ru';
$Vk = 'r.kaydaulov';
// FFBA00