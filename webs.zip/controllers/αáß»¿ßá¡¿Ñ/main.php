<?php
auth('password');
/*
*Переменные
*/
$title = 'Расписание';
$author = 'Учитель';
$script_file = SERVER . '/js/core.js';