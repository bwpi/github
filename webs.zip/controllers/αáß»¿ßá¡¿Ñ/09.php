<?php
/*
*Переменные
*/
$title = 'Расписание';
$author='Алексеев';
$Email = 'artem_artem_v0_alekseev@mail.ru';
$color = getColor('ff4500');
$Vk = 'sorry_vs';