<?php
/**
 * Core::factory('Menu')
* ->sorting('key', '=' , 100)
* ->where('a=2')
* ->templates('menu')
* ->show();
 */
/*
* Подключение персонального контроллера
$head
$storage_views || $content
$script_file
$scripts
*/
// debug($_SERVER);
// $storage_views = $controller . '/' . $view;

$file_path = ROOT . '/' . str_replace('+', " ",$_SERVER[QUERY_STRING]);
if (file_exists($file_path)) {
    if(is_file($file_path)){        
        // ob_end_clean();        
        header('Content-Description: File Transfer');
        header('Content-Type: ' . mime_content_type($file_path));
        header('Content-Disposition: attachment; filename=' . basename($file_path));
        header('Content-Transfer-Encoding: binary');
        header('Content-Length: ' . filesize($file_path));
        readfile($file_path);
        exit();
    }
}

$Fs = new Fs(ROOT . "/$controller/");
if (isset($_GET['dir'])&&!empty($_GET['dir'])) {
    $dir = $_GET['dir'];
    $content = Temp::templates('buttons', $Fs->setCatalog($dir)->dirScan()->showInTo($dir));    
} else {    
    $content = Temp::templates('buttons', $Fs->scanRec()->show());
}
debug($Fs);