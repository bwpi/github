$('.card h4').click(function () {
    $(this).next('div.card-container').toggleClass('active');
})