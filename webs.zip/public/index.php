<?php
/*
*Включение ошибок
*/
// ini_set('error_reporting', E_ALL);
// ini_set('display_errors', 1);
// ini_set('display_startup_errors', 1);

/*
* Загрузка файла конфигурации
*/
include ('../libs/config.php');
/*
* Загрузка файла фукнций
*/
include (LIBS . 'func.php');
/*
* Реализация автозагрузки контроллера, модели и вида
*/
$routes = explode('&', $_SERVER['QUERY_STRING']);
$routes = explode('/', $routes[0]);

/*
* Правила маршрутизации
*/

$routes[0] = dispatch('shedules', 'расписание', $routes);
$routes[0] = dispatch('07', 'contests', $routes);

/****** */
if (!file_exists(CTRLS . $routes[0] . '.php')){
    $routes[0] = 'main';    
}
if (!$routes[1]){
    $routes[1] = 'main';
    // include VIEWS . 'layout/404.html';
    // exit;
}

$controller = $routes[0];
$view = $routes[1];
$param = $routes[2];

/*
* Загрузка контроллера
*/
include (CTRLS . $controller . '.php');