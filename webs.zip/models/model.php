<?php

function readData($file_name = '', $mode=true){
	return json_decode(file_get_contents($file_name), $mode);
}

function rewriteData($file_name = '', $data = '', $path = []){
	/*
	* Функция обработки файла по заданным правилам и перезапись новыми данными
	*/
	echo "Файл {$file_name}, был успешно перезаписан новыми данными {$data}, по пути...";
}

function dirScan($dir = FILES){
	$files = scandir($dir);
	unset($files[0], $files[1]);
	return array_values($files);
}

function sortJsonFiles($files = []){
	$out = [];
	foreach ($files as $value) {
		$name = explode('.', $value);
		if ($name[1]==='json') {		
			array_push($out, $name[0]);
		}
	}
	sort($out, SORT_NATURAL);
	return $out;
}

function sortDataType($data, ...$sorts){
	$in = $data;
	foreach ($sorts as $sort){
		foreach ($in as $key => $value){
			$find = strpos($value, $sort);
			if($find !== false) {		
				unset($in[$key]);
			}		
		}	
	}	
	return $in;
}