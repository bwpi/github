<?php
echo 'Все ок';