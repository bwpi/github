<?php
define('ROOT', '../');
define('FILES', ROOT . 'files/');
define('LIBS', ROOT . 'libs/');
define('CTRLS', ROOT . 'controllers/');
define('MODELS', ROOT . 'models/');
define('VIEWS', ROOT . 'views/');
define('SERVER', $_SERVER['HTTP_ADDRESS']);