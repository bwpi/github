<?php

function debug($arr) {
    echo '<pre>' . print_r($arr, true) . '</pre>';
}

function dispatch($in, $out, $routes) {    
    return ($routes[0] == $in) ? $out : $routes[0];
}