<?php
function auth($password = '') {
	if (!isset($_GET['auth'])||($_GET['auth']!=$password)) {
		echo 'Отказано в доступе - ' . $_SERVER[REMOTE_ADDR];
		echo '<a href="http://' . $_SERVER['HTTP_HOST'] . '/login/">Авторизуйтесь</a>';
		exit;
	}
}