<?php 
/**
 * ООП
 * Классы
 * Объекты
 * Методы
 * Свойства
 * и прочее
 */
class Fs {
    public $dir = '';
    public $catalog = '';
    public $direct = [];
    public $temp_array = [];
    private $array = [];
    
    function __construct($dir){
        $this->dir = $dir;
    }
    public function dirScan(){        
        $files = scandir($this->dir . $this->catalog);
        unset($files[0], $files[1]);
        $this->array = array_values($files);
        return $this; 
    }
    public function setCatalog($catalog) {
        $this->catalog = $catalog;
        return $this;
    }
    public function setDir($dir) {
        $this->dir = $dir;
        return $this;
    }
    public function scanRec() {        
        $path = $this->dir;
        if (is_dir($path)) {
            $dir_scan = array_slice(scandir($path . '/'), 2);            
            foreach ($dir_scan as $key => $value) {
                $file = $path . '/' . $value;
                if (is_file($file)) {
                    // $direct = $value;
                    $data = [
                        'name' => $value,
                        // 'type' => mime_content_type($file),
                        // 'size' => round(stat($file)[7]/1024, 2),
                        // 'atime' => date("d F Y H:i:s", stat($file)[8]),
                        // 'mtime' => date("d F Y H:i:s", stat($file)[9])
                    ];
                    // implode('/', $data);
                    array_push($this->direct, implode('/', $data));
                    
                } else {                    
                    $this->direct[$value] = scanRec($this->dir . '/' . $value);
                }                
            }            
        } else {
            echo 'no dir' . $path;
        }
        ksort($this->direct, SORT_STRING);
        return $this;
    }
    /**
     * Формирование адреса в адресной строке
     */
    private function setWebPath($catalog, $show_host = true) {
        if ($show_host) {
            $host = "http://" . $_SERVER['HTTP_HOST'] . "/" . CURRENT_CONTROLLER . '/';
        }
        return $host . $catalog;      
    }
    public function show() {        
        $out = '';  
        foreach ($this->direct as $key => $value) {
            if (is_dir($this->dir . $key)) {
                array_push($this->temp_array, [
                    'name' => $this->setWebPath($key . '/', false),
                    'style' => 'directory',                    
                    'type' => 'dir',
                    'href' => '?dir=' . $key . '/',
                    'exec' => '',
                ]);
            } else {
                array_push($this->temp_array, [
                    'name' => $this->setWebPath($value, false),
                    'style' => 'green files',                    
                    'type' => 'file',
                    'href' => $this->setWebPath($value),
                    'exec' => explode('.', $value)[1],
                ]);
            }		
        }
        
        return Temp::templates('a', $this->temp_array);
    }
    public function showInTo($dir = '') {
        $out = ''; 	
        foreach ($this->array as $key => $value) {		
            if (is_dir($this->dir . $this->catalog . $value)) {
                array_push($this->temp_array, [
                    'name' => $this->setWebPath($value, false),
                    'style' => 'directory',                    
                    'type' => 'dir',
                    'href' => '?dir=' . $dir . $value . '/',
                    'exec' => '',
                ]);                
            } else {
                array_push($this->temp_array, [
                    'name' => $this->setWebPath($value, false),
                    'style' => 'green files',                    
                    'type' => 'file',
                    'href' => $this->setWebPath($dir . $value),
                    'exec' => explode('.', $value)[1],
                ]);                
            }		
        }
        return Temp::templates('a', $this->temp_array);
    }
}