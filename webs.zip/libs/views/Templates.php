<?php
/**
 * fu('html', $array);
 */
class Temp {
	static public function templates($templates = '', $array = []) {
        ob_start();
        include ROOT . '/temp/' . $templates . '.html';
        return ob_get_clean();
    }
    static public function test($var = '') {
        debug($var);
    }
}
// echo Temp::templates('temp', [1000, 5000]);