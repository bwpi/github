<?php

namespace app\controllers;

class TeacherController extends AppController{  
    
    public function indexAction(){
        
    }
    
}