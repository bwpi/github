<?php

namespace app\controllers;

class ApiController extends AppController{  
    
    public function indexAction(){
        $this->layout = false;
        echo 'API сервера';
        if ($this->isAjax()) {           
            
            if ($_SERVER['REQUEST_METHOD'] === 'GET') {
                debug($_GET);
                echo "Метода GET в HTTP используется для получения информации от сервера по заданному URI (URI в HTTP). Запросы клиентов, использующие метод GET должны получать только данные и не должны никак влиять на эти данные.";
            } elseif ($_SERVER['REQUEST_METHOD'] === 'POST') {
                debug($_POST);
                echo "HTTP метод POST используется для отправки данных на сервер, например, из HTML форм, которые заполняет посетитель сайта.";
            } elseif ($_SERVER['REQUEST_METHOD'] === 'PUT') {                
                foreach (explode('&', file_get_contents("php://input")) as $key => $value) {
                    $explode = explode('=', $value);
                    $_PUT[$explode[0]] = $explode[1];
                }                
                debug($_PUT);
                echo "HTTP метод PUT используется для загрузки содержимого запроса на указанный в этом же запросе URI. Обновление";
            } elseif ($_SERVER['REQUEST_METHOD'] === "DELETE") {
                foreach (explode('&', file_get_contents("php://input")) as $key => $value) {
                    $explode = explode('=', $value);
                    $_DELETE[$explode[0]] = $explode[1];
                }                
                debug($_DELETE);
                echo "HTTP метод DELETE используется для удаления содержимого запроса.";
            } else {
                echo 'Нет метода';
            }
            die;
        }
    }
    
}