<?php

namespace app\controllers;

class StudyController extends AppController{  
    
    public function indexAction(){
        
    }
    
}