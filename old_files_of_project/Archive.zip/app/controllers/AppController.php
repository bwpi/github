<?php

namespace app\controllers;

use vendor\core\base\Controller;

class AppController extends Controller{    

    
    
}