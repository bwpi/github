<?php

namespace app\controllers;

use vendor\core\IpAuth;
use app\views\View;
use app\models\AdminModels;

class MainController extends AppController{

    public $data = [];    

    public function indexAction() {
        $model = new AdminModels();
        $IpAuth = new IpAuth();
        $this->data = $model->fromJsonToArrayOrJson('time');
        $array = $model->fromJsonToArrayOrJson('time');

        /*
        * Обработка AJAX запроса
        */
        if ($this->isAjax()) {
            if (!empty($_POST['ajax_time'])) {
                echo json_encode($this->data);                
            } else {            
                $this->loadView($this->view, compact('array'));
            }
            die;
        }

        //проверка ip адреса        
        $ip = $IpAuth->ipAuth(REMOTE_ADDR);
        $rule = $IpAuth->setViewAuth();
        $this->view = $rule;        
        $title = $IpAuth->getProfile()->$rule->title;
        $main = $IpAuth->getProfile()->$rule->main;
        $set = $IpAuth->getProfile()->$rule->set;
        $auth = $IpAuth->getProfile()->$rule->auth;        
        $this->setData(compact('title', 'main', 'set', 'auth', 'ip', 'array'));
    }

    public function scheduleAction() {

        $model = new AdminModels();
        $IpAuth = new IpAuth();        
        //проверка ip адреса
        $ip = $IpAuth->ipAuth(REMOTE_ADDR);
        $rule = $IpAuth->setViewAuth();

        $array = $model->fromJsonToArrayOrJson('schedule');
        $objects = $model->getUserSettings('objects', $rule);
        /*
        * Обработка AJAX запроса
        */
        if ($this->isAjax()) {            
            $this->loadView($this->view, compact('array', 'objects'));
            die;
        }        
        $this->setData(compact('array', 'objects'));
    }

    public function timeAction() {
        $model = new AdminModels();
        $this->data = $model->fromJsonToArrayOrJson('time');
        $array = $model->fromJsonToArrayOrJson($this->view);        
        /*
        * Обработка AJAX запроса
        */
        if ($this->isAjax()) {
            if (!empty($_POST['ajax_time'])) {
                echo json_encode($this->data);                
            } else {            
                $this->loadView($this->view, compact('array'));
            }
            die;
        }
        $this->setData(compact('array'));
        
    }   
    
}