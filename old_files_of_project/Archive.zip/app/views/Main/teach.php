<div class="cover-container d-flex w-100 h-100 p-3 mx-auto flex-column">
<div class="inner">
<nav class="navbar navbar-expand-md navbar-dark bg-transparent shadow-lg" id="nav">
    <a class="navbar-brand" href="<?=HTTP_HOST;?>"><img src="<?=HTTP_HOST;?>img/bg1.png" alt="Админка" width="30em" class="icons"></a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExample03" aria-controls="navbarsExample03" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarsExample03">
        <ul class="navbar-nav mr-auto adms">
            <a href="http://seo.gsosh-gari.ru" target="_blank" class="nav-link btn bg-transparent">СЭО<img src="<?=HTTP_HOST;?>img/logo_0.png" alt="СЭО МКОУ ГСОШ" width="30em" class="icons"></a>
            <li class="nav-item dropdown active">
                <a class="nav-link dropdown-toggle btn bg-transparent" href="#" id="dropdown1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <font style="vertical-align: inherit;">РИС-ы</font>
                </a>
                <div class="dropdown-menu bg-dark" aria-labelledby="dropdown1">
                    <div class="btn-group-vertical btn-block" role="group" aria-label="СТАТГРАД">
                        <a href="https://support.gia66.ru/" target="_blank" class="btn btn-danger">Поддержка ГИА</a>
                        <a href="http://192.168.16.24" target="_blank" class="btn btn-danger adms sup">РИС</a>
                        <a href="http://192.168.16.50" target="_blank" class="btn btn-danger adms sup">Сервер статистики</a>
                        <a href="http://ikt.gia66.ru" target="_blank" class="btn btn-danger adms sup">Сервер ИКТ</a>
                        <a href="http://video.gia66.ru" target="_blank" class="btn btn-danger adms sup">Сервер Видео</a>
                        <a href="https://vpr.statgrad.org/" target="_blank" class="btn btn-success">ВПР СТАТГРАД</a>
                        <a href="https://statgrad.org/" target="_blank" class="btn btn-info">СТАТГРАД</a>
                        <a href="http://kais.irro.ru/" target="_blank" class="btn btn-light">КАИС ИРРО</a>
                        <a href="https://monitoring.abbyy.ru/" target="_blank" class="btn btn-warning">Abbyy monitoring</a>
                    </div>
                </div>
            </li>
            <li class="nav-item dropdown active sup">
                <a class="nav-link dropdown-toggle btn btm-circle bg-transparent" href="#" id="dropdown2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <font style="vertical-align: inherit;"><img src="<?=HTTP_HOST;?>img/cons.png" alt="Веб-админки" width="20em"></font>
                </a>
                <div class="dropdown-menu bg-dark" aria-labelledby="dropdown2">
                    <div class="btn-group-vertical btn-block">
                        <a href="https://192.168.1.29:10000" target="_blank" class="btn btn-danger" data-toggle="tooltip" data-placement="right" title="Веб-мин консоль на центральный сервер gsoshcu">Центральный сервер</a>
                        <a href="http://ics.gsosh-gari.ru:81" target="_blank" class="btn btn-danger" data-toggle="tooltip" data-placement="right" title="Веб-админ консоль на контент-фильтре icscu">Контент-фильтр</a>
                        <a href="https://192.168.1.31:10000" target="_blank" class="btn btn-warning" data-toggle="tooltip" data-placement="right" title="Веб-админ консоль на центральный сервер webcu">Веб-сервер</a>
                        <a href="http://192.168.1.29/virtualbox" target="_blank" class="btn btn-dark" data-toggle="tooltip" data-placement="right" title="Веб-админ консоль на виртуальный сервер gsoshcu">VirtualBox_g</a>
                        <a href="http://192.168.1.31" target="_blank" class="btn btn-primary" data-toggle="tooltip" data-placement="right" title="Веб-админ консоль на виртулаьный сервер webcu">VirtualBox_w</a><br>
                        <a href="http://192.168.1.3:9080" target="_blank" class="btn btn-info" data-toggle="tooltip" data-placement="right">ЦУ Др.Веб</a>
                        <a href="http://192.168.1.4:5280/admin" target="_blank" class="btn btn-info" data-toggle="tooltip" data-placement="right">ЦУ Jabber</a>
                    </div>
                </div>
            </li>
            <li class="nav-item dropdown active sup">
                <a class="nav-link dropdown-toggle btn bg-transparent" href="#" id="dropdown3" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <font style="vertical-align: inherit;"><img src="<?=HTTP_HOST;?>img/routers.png" alt="Роутеры" width="20em"></font>
                </a>
                <div class="dropdown-menu bg-dark" aria-labelledby="dropdown3">
                    <div class="btn-group-vertical btn-block">
                        <a class="btn btn-danger" target="_blank" href="http://192.168.1.1">
                            <font style="vertical-align: inherit;">Модем</font>
                        </a>
                        <a class="btn btn-danger" target="_blank" href="http://10.10.0.241">
                            <font style="vertical-align: inherit;">1-й Этаж</font>
                        </a>
                        <a class="btn btn-danger" href="#">
                            <font style="vertical-align: inherit;">2-й Этаж</font>
                        </a>
                        <a class="btn btn-danger" target="_blank" href="http://10.10.0.244">
                            <font style="vertical-align: inherit;">3-й Этаж</font>
                        </a>
                    </div>
                </div>
            </li>
            <a class="nav-link btn btn-transparent giaMenu sup" target="_blank" data-toggle="collapse" href="#giaMenu" role="button" aria-expanded="false" aria-controls="collapseExample">
                <font style="vertical-align: inherit;">ГИА</font>
            </a>
            <a class="nav-link btn btn-transparent" data-toggle="modal" data-target="#calend">
                <font style="vertical-align: inherit;">Календарь</font>
            </a>
            <a class="nav-link btn btn-transparent rassp1" data-toggle="modal" data-target="#ras">
                <font style="vertical-align: inherit;">Расписание</font>
            </a>
            <a class="nav-link btn btn-transparent historyAPI report" id="report" href="report.html">
                <font style="vertical-align: inherit;">Отчеты</font>
            </a>
            <a class="nav-link btn btn-transparent bg-setting">
                <font style="vertical-align: inherit;">Настройки</font>
            </a>
        </ul>
        <ul class="navbar-nav mr-auto user">
            <a href="http://seo.gsosh-gari.ru" target="_blank" class="btn bg-transparent">СЭО<img src="<?=HTTP_HOST;?>img/logo_0.png" alt="СЭО МКОУ ГСОШ" width="30em" class="icons shadow-sm"></a>
            <a class="nav-link btn btn-transparent" target="_blank" href="http://robotlandia.ru/abc5/index.htm">
                <font style="vertical-align: inherit;">Scratch 2</font>
            </a>
            <a class="nav-link btn btn-transparent" target="_blank" href="https://scratch.mit.edu">
                <font style="vertical-align: inherit;">Scratch 3</font>
            </a>
            <a class="nav-link btn btn-transparent" data-toggle="modal" data-target="#calend">
                <font style="vertical-align: inherit;">Календарь</font>
            </a>
            <a class="nav-link btn btn-transparent rassp1" data-toggle="modal" data-target="#ras">
                <font style="vertical-align: inherit;">Расписание</font>
            </a>
        </ul>
    </div>
    <div class="adms user_name navi_dash">
        <?php echo $user_name;?>
    </div>
    <div class="adms sup navi_dash">
        <a class="btn btn-transparent navi_dash" id="edit_ip"><i class="fas fa-plus"></i>IP</a>
    </div>

    <form class="form-horizontal navi_dash search" role="form" action="https://yandex.ru/search/" role="search" aria-label="Поиск в интернете">
        <div class="input-group">
            <input type="text" class="form-control" placeholder="Поиск Яндекса" autocomplete="off" autocorrect="off" autocapitalize="off" spellcheck="false" aria-autocomplete="list" aria-label="Запрос" id="text" maxlength="400" name="text" autofocus>
            <div class="input-group-append">
                <button class="btn btn-success" data-bem="{&quot;button&quot;:{}}" tabindex="-1" role="button" type="submit">Поиск</button>
            </div>
        </div>
    </form>
    <div class="adms">
        <a class="btn btn-transparent navi_dash" data-target="#reg" id="add_users"><i class="fas fa-user-plus"></i></a>
        <a class="btn btn-transparent navi_dash" id="users"><i class="fas fa-users"></i></a>
        <a class="btn btn-transparent navi_dash" id="edit"><i class="fas fa-user-edit"></i></a>
        <a class="btn btn-transparent navi_dash" id="key"><i class="fas fa-key"></i></a>
        <a class="btn btn-transparent navi_dash login" data-toggle="modal" data-target="#auth"><i class="fas fa-user"></i></a>
        <a class="btn btn-transparent navi_dash logout" href="?exit"><i class="fas fa-user-check text-light"></i></a>
    </div>
</nav>
<!-- Button trigger modal -->
<!-- Календарь -->
<div class="modal fade" id="calend" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content bg-dark">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
            </div>
            <div class="modal-body" id="cal_modal">
                <?php include WWW . '/cal.php';?>
            </div>
        </div>
    </div>
</div>
<!-- Рассписание -->
<div class="modal fade bd-example-modal-lg" id="ras" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content bg-dark">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
            </div>
            <div class="modal-body rassp_modal">
                ...
            </div>
        </div>
    </div>
</div>
<!-- Авторизация -->
<div class="modal fade adms" id="auth" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content bg-dark">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLongTitle">Авторизация</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
            </div>
            <div class="modal-body">
                <form name="autorization" action="" method="POST">
                    <div class="form-group">
                        <label for="exampleInputEmail1">Логин</label>
                        <input type="text" name="login" class="form-control" placeholder="Введите логин">
                    </div>
                    <div class="form-group">
                        <label for="exampleInputPassword1">Пароль</label>
                        <input type="password" name="password" class="form-control" placeholder="Введите пароль">
                    </div>
                    <div class="form-check">
                        <input type="checkbox" name="save_cookie" value=1 class="form-check-input">
                        <label class="form-check-label" for="exampleCheck1">Запомнить</label>
                    </div>
                    <button name="data" value="Вход" class="btn btn-primary">Войти</button>
                </form>
            </div>
        </div>
    </div>
</div>
<!-- Регистрация -->
<div class="modal fade adms" id="reg" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content bg-dark">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLongTitle">Регистрация пользователей</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
            </div>
            <div class="modal-body">
                <form name="reg" action="<?=HTTP_HOST;?>/editors/index.php" method="POST">
                    <input type="text" class="form-control mb-1" name="name" placeholder="Имя">
                    <input type="text" class="form-control mb-1" name="f_name" placeholder="Фамилия">
                    <input type="text" class="form-control mb-1" name="login" placeholder="Логин">
                    <input type="password" class="form-control mb-1" name="password" placeholder="Пароль">
                    <button type="submit" name="data">Сохранить</button>
                </form>
            </div>
        </div>
    </div>
</div>
<div class="adms" id="settings">
    <?php include $_SERVER['DOCUMENT_ROOT'] . '/blocks/html/adm.html';?>
</div>
<!--a class="btn btn-transparent fixed-bottom m-2" href="#nav" id="sb"><i class="fas fa-arrow-up"></i></a-->
<div class="modal" id="addModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content bg-dark">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLongTitle">Добавление кнопки</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
            </div>
            <div class="modal-body">
                <form id="addButtons">
                    <div class="form-group">
                        <label for="recipient-name" class="col-form-label">Имя кнопки</label>
                        <input type="text" class="form-control" id="name">
                    </div>
                    <div class="form-group">
                        <label for="message-text" class="col-form-label">ID</label>
                        <input type="text" class="form-control" id="id">
                    </div>
                    <div class="form-group">
                        <label for="message-text" class="col-form-label">Class</label>
                        <input type="text" class="form-control" id="cl">
                    </div>
                    <div class="form-group">
                        <label for="message-text" class="col-form-label">Ссылка</label>
                        <input type="text" class="form-control" id="href">
                    </div>
                    <div class="custom-control custom-switch">
                        <input type="checkbox" value=1 class="custom-control-input" id="blank">
                        <label class="custom-control-label" for="blank">В новом окне</label>
                    </div>
                    <div class="custom-control custom-switch">
                        <input type="checkbox" class="custom-control-input" id="historyAPI">
                        <label class="custom-control-label" for="historyAPI">Запрет перехода по ссылке</label>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary off" data-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary ok">OK</button>
            </div>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-md">
        <div class="alert alert-white bg-transparent bg-dark shadow-lg" role="alert">Выход в интернет осуществлять строго с данной страницы. Обязательно прочтите
            <button type="button" class="btn btn-danger" data-toggle="modal" data-target="#usersModal">
        Пользовательское соглашение
    </button>
            <a class="btn btn-warning" id="que_st">Опросы</a>
        </div>
    </div>
</div>
<div class="modal fade" id="usersModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content bg-dark">
            <div class="modal-header">
                <h5 class="modal-title">Правила пользования сайтом</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
            </div>
            <div class="modal-body">
                <div class="text-white text-left" role="alert">
                    Перед вами стартовая станица доступа к сети интернет.<br/> 1. Менять ее в настройках браузера категорически запрещено!<br/> 2. На данной странице размещаются ссылки на инфомрационные системы школы, cервисы сети иинтернет образовательной
                    направленности.<br/> 3. Ссылки сгруппированы по категориям.<br/> 4. Ссылки будут пополняться, категории размещаться.<br/> Предложения по совершенстованию данной инфомационной страницы подавать Администратору системы.<br/> Если есть
                    собственные идеи по совершенстованию сайта - предлагайте.<br/>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-danger" data-dismiss="modal" id="sub_users">Принять условия</button>
            </div>
        </div>
    </div>
</div>
</div>
<form class="form-horizontal" role="form" action="https://yandex.ru/search/" role="search" aria-label="Поиск в интернете" data-bem="{&quot;suggest2-form&quot;:{},&quot;suggest2-counter&quot;:{&quot;service&quot;:&quot;morda_ru_desktop&quot;,&quot;host&quot;:&quot;//yandex.ru/clck&quot;,&quot;path&quot;:&quot;jclck&quot;,&quot;submitBySelect&quot;:true,&quot;preventSubmit&quot;:true,&quot;suggestReqID&quot;:true,&quot;params&quot;:{&quot;dtype&quot;:&quot;stred&quot;,&quot;pid&quot;:&quot;0&quot;,&quot;cid&quot;:&quot;2873&quot;}},&quot;search2&quot;:{&quot;cleanOnSubmit&quot;:false,&quot;nl&quot;:true}}">
	<div class="row">
	<div class="col-md-10">
	<input class="form-control" type="text" placeholder="Поиск Яндекса" autocomplete="off" autocorrect="off" autocapitalize="off" spellcheck="false" aria-autocomplete="list" aria-label="Запрос" id="text" maxlength="400" name="text" autofocus>
	</div> 
	<div class="col-md-2">
	<button class="btn btn-success btn-block" data-bem="{&quot;button&quot;:{}}" tabindex="-1" role="button" type="submit">Поиск</button>
	</div>
	</div>
</form>
<div class="row">
    <div class="col-sm-12">       
        <div id="cont_ent"><div class="row">
    <div class="col-sm-4">
        <div class="h6">Обучающие ресурсы</div>
        <div class="btn-group-vertical btn-block shadow-lg">
            <a href="http://dnevnik.ru" target="_blank" class="btn btn-light btn-block href"><img src="https://static.dnevnik.ru/img/logotypes/logotype.png" alt="Дневник.ру" height="20em"></a>
            <a href="http://learningapps.org" target="_blank" class="btn btn-info btn-block href"><img class="images" src="<?=HTTP_HOST;?>img/logo.png" alt="Learningapps.org" height="20em"></a>
            <a href="http://plickers.com" target="_blank" class="btn btn-success btn-light href"><img class="images" src="<?=HTTP_HOST;?>img/logo_5.png" alt="plickers.com" height="20em"></a>
        </div>
    </div>
    <div class="col-sm-4">
        <div class="h6">Оффициальные сайты</div>
        <div class="btn-group-vertical btn-block shadow-lg">
            <a href="http://gsosh-gari.ru" target="_blank" class="btn btn-warning btn-block href"><img class="images" src="<?=HTTP_HOST;?>img/logo1.png" alt="Сайт школы" height="20em">Сайт МКОУ ГСОШ</a>
            <a href="http://ege.edu.ru" target="_blank" class="btn btn-info btn-light href"><img class="images" src="<?=HTTP_HOST;?>img/logo2.png" alt="ЕГЭ 2019" height="20em"></a>
            <a href="http://gia.edu.ru" target="_blank" class="btn btn-success btn-light href"><img class="images" src="<?=HTTP_HOST;?>img/logo3.png" alt="ОГЭ 2019" height="20em"></a>
            <a href="https://support.gia66.ru/" target="_blank" class="btn btn-danger btn-block adms href">Техподдержка ГИА</a>
            <a href="https://lk-fisoko.obrnadzor.gov.ru/" target="_blank" class="btn btn-danger btn-block adms href">ФИС ОКО</a>
            <a href="https://vpr.statgrad.org/" target="_blank" class="btn btn-success btn-block adms href">Статград ВПР</a>
            <a href="https://statgrad.org/" target="_blank" class="btn btn-info btn-block adms href">Статград</a>
            <a href="http://kais.irro.ru/" target="_blank" class="btn btn-light adms href">КАИС ИРРО</a>
        </div>
    </div>
    <div class="col-sm-4">
        <div class="h6">Системы обучения и подготовки</div>
        <div class="btn-group-vertical btn-block shadow-lg">
            <!--a href="servises.php" class="btn btn-info btn-block">Сервисы</a-->
            <a href="http://testedu.ru" target="_blank" class="btn btn-success btn-block href">Образовательные тесты</a>
            <a href="https://testschool.ru" target="_blank" class="btn btn-success btn-block href">Школьные тесты</a>
            <a href="http://kpolyakov.spb.ru/" target="_blank" class="btn btn-light btn-block href">Сайт К.Полякова</a>
        </div>
    </div>
</div></div>
    </div>
</div>
</div>
<div class="information d-none">
<div class="h5">Опросы</div>
<a class="btn btn-warning mt-5 btn-lg" target="_blank" href="http://test2.ozdorovlenie-nii.ru:8080/#">Исследование</a>
<p>Социально-педагогическое исследование для учащихся 6-11 классов.</p>
<ul>
    <li>1. Нажмите на ссылку выше.</li>
    <li>2. Введите логин и пароль с листочка.</li>
    <li>1. Ответьте на все вопросы.</li>
</ul>
</div>