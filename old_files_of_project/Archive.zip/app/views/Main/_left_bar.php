<div class="ktp collapse" id="ktpMenu">
<div class="h3">КТП Информатика</div>
  <div class="btn-group-vertical btn-block shadow-lg">
    <div class="btn-group btn-block">
      <a class="btn btn-info kt historyAPI" id="5_ktp_inf" href="5_ktp_inf.html"><font style="vertical-align: inherit;">5-класс</font></a>
      <a class="btn btn-info kt historyAPI" id="5K_ktp_inf" href="5K_ktp_inf.html"><font style="vertical-align: inherit;">5К-класс</font></a>
    </div>
    <div class="btn-group btn-block">
      <a class="btn btn-success kt historyAPI" id="6_ktp_inf" href="6_ktp_inf.html"><font style="vertical-align: inherit;">6-класс</font></a>
      <a class="btn btn-success kt historyAPI" id="6K_ktp_inf" href="6K_ktp_inf.html"><font style="vertical-align: inherit;">6К-класс</font></a>
    </div>
  <a class="btn btn-primary kt historyAPI" id="7_ktp_inf" href="7_ktp_inf.html"><font style="vertical-align: inherit;">7-класс</font></a>
  <a class="btn btn-secondary kt historyAPI" id="8_ktp_inf" href="8_ktp_inf.html"><font style="vertical-align: inherit;">8-класс</font></a>
  <a class="btn btn-success kt historyAPI" id="9_ktp_inf" href="9_ktp_inf.html"><font style="vertical-align: inherit;">9-класс</font></a>
  <a class="btn btn-warning kt historyAPI" id="10_ktp_inf" href="10_ktp_inf.html"><font style="vertical-align: inherit;">10-класс</font></a>
  <a class="btn btn-info kt historyAPI" id="11_ktp_inf" href="11_ktp_inf.html"><font style="vertical-align: inherit;">11-класс</font></a>
</div>
<div class="h3">КТП Физика</div>
  <div class="btn-group-vertical btn-block shadow-lg">    
  <a class="btn btn-primary kt historyAPI" id="7_ktp_fiz" href="7_ktp_fiz.html"><font style="vertical-align: inherit;">7-класс</font></a>
  <a class="btn btn-secondary kt historyAPI" id="8_ktp_fiz" href="8_ktp_fiz.html"><font style="vertical-align: inherit;">8-класс</font></a>
  <a class="btn btn-success kt historyAPI" id="9_ktp_fiz" href="9_ktp_fiz.html"><font style="vertical-align: inherit;">9-класс</font></a>
  <a class="btn btn-warning kt historyAPI" id="10_ktp_fiz" href="10_ktp_fiz.html"><font style="vertical-align: inherit;">10-класс</font></a>
  <a class="btn btn-info kt historyAPI" id="11_ktp_fiz" href="11_ktp_fiz.html"><font style="vertical-align: inherit;">11-класс</font></a>
</div>
</div>
<div class="ga collapse" id="giaMenu">
  <div class="h3">Меню экзаменов 2019</div> 
    <div class="h4">ОГЭ</div>
    <a class="btn btn-block btn-warning gia" target="_blank" href="https://domege-my.sharepoint.com/:f:/g/personal/user13_domege_onmicrosoft_com/Ekuifc_7WVRLuiFu7YnppYYBlieBfbCwZCv9TjVT7bgZvA?e=VmyEYx">Облако</a>
      <div class="btn-group-vertical btn-block shadow-lg">
        <a class="btn btn-primary gia historyAPI" id="ko" href="ko.html">Календарь экзаменов</a>
        <a class="btn btn-secondary gia historyAPI" id="kos" href="kos.html">Статусы</a>
        <a class="btn btn-success gia historyAPI" id="koss" href="koss.html">Сдающие</a>
        <a class="btn btn-info gia historyAPI" id="koo" href="koo.html">Организаторы</a>
      </div>
    <div class="h4">ЕГЭ</div>
      <div class="btn-group-vertical btn-block shadow-lg">
        <a class="btn btn-primary gia historyAPI" id="ke" href="ke.html">Календарь экзаменов</a>
        <a class="btn btn-secondary gia historyAPI" id="kes" href="kes.html">Статусы</a>
        <a class="btn btn-success gia historyAPI" id="kess" href="kess.html">Сдающие</a>
        <a class="btn btn-info gia historyAPI" id="keo" href="keo.html">Организаторы</a>
      </div>
</div>
<div class="work">
<div class="h3">Рабочая панель</div>
<div class="btn-group-vertical btn-block shadow-lg">
  <a class="btn btn-info kt" id="5_ktp_inf" data-toggle="collapse" href="#ktpMenu" role="button" aria-expanded="false" aria-controls="collapseExample">Календарно-тематический план</a>
  <a class="btn btn-primary rassp historyAPI" href="main/schedule">Расписание</a>
  <a class="btn btn-primary rassp historyAPI" href="main/time">Звонки</a>
  <a class="btn btn-secondary cal historyAPI" id="cal" href="cal.html">Календарь</a>
  <a class="btn btn-info quest historyAPI" id="quest" href="quest.html">Опросы</a>
  <a href="https://mail.yandex.ru/?uid=38634928#inbox" target="_blank" class="btn btn-light p-1"><img src="http://gsoshcu/info/files//img/yandex.png" alt="ЯндексПочта" width="70em"></a>
  <a href="https://e.mail.ru/messages/inbox/" target="_blank" class="btn btn-info p-1"><img src="http://gsoshcu/info/files//img/mail.png" alt="МайлПочта" width="70em"></a>
</div>
<div class="h3">Рабочие ссылки</div>
<div class="btn-group-vertical btn-block shadow-lg">
  <a class="btn btn-dark" target="_blank" href="thems/support.php"><font style="vertical-align: inherit;">Поддержка</font></a>
  <a class="btn btn-dark" target="_blank" href="thems/user.php"><font style="vertical-align: inherit;">Общая</font></a>
  <a class="btn btn-dark" target="_blank" href="http://gsoshcu/info/school.info/"><font style="vertical-align: inherit;">Разработка</font></a>
  <a class="btn btn-dark" target="_blank" href="http://gsoshcu:88"><font style="vertical-align: inherit;">Разработка</font></a>
</div>
</div>  					