<div class="cover-container d-flex w-100 h-100 p-3 mx-auto flex-column">
    <?php include VIEWS . "{$this->route['controller']}/_navbar.php"?>
    </div>
    <div class="h3 text-center m-2"><?= $main;?></div>    
    <div class="row">
        <div class="col-lg-3 d-none d-sm-block" id="left_panel">            
            <?php include VIEWS . "{$this->route['controller']}/_left_bar.php"?>
        </div>
        <div class="col-lg-9">            
            <div id="content">
                <div class="col-sm-4">
    <div class="h6">Обучающие ресурсы</div>
    <div class="btn-group-vertical btn-block shadow-lg">
        <a href="http://dnevnik.ru" target="_blank" class="btn btn-light btn-block href"><img
                src="https://static.dnevnik.ru/img/logotypes/logotype.png" alt="Дневник.ру"
                height="20em"></a>
        <a href="http://learningapps.org" target="_blank" class="btn btn-info btn-block href"><img
                class="images" src="<?=HTTP_HOST;?>img/logo.png" alt="Learningapps.org"
                height="20em"></a>
        <a href="http://plickers.com" target="_blank" class="btn btn-success btn-light href"><img
                class="images" src="<?=HTTP_HOST;?>img/logo_5.png" alt="plickers.com" height="20em"></a>
    </div>
</div>
<div class="col-sm-4">
    <div class="h6">Оффициальные сайты</div>
    <div class="btn-group-vertical btn-block shadow-lg">
        <a href="http://gsosh-gari.ru" target="_blank" class="btn btn-warning btn-block href"><img
                class="images" src="<?=HTTP_HOST;?>img/logo1.png" alt="Сайт школы" height="20em">Сайт
            МКОУ ГСОШ</a>
        <a href="http://ege.edu.ru" target="_blank" class="btn btn-info btn-light href"><img
                class="images" src="<?=HTTP_HOST;?>img/logo2.png" alt="ЕГЭ 2019" height="20em"></a>
        <a href="http://gia.edu.ru" target="_blank" class="btn btn-success btn-light href"><img
                class="images" src="<?=HTTP_HOST;?>img/logo3.png" alt="ОГЭ 2019" height="20em"></a>
        <a href="https://support.gia66.ru/" target="_blank"
            class="btn btn-danger btn-block adms href">Техподдержка ГИА</a>
        <a href="https://lk-fisoko.obrnadzor.gov.ru/" target="_blank"
            class="btn btn-danger btn-block adms href">ФИС ОКО</a>
        <a href="https://vpr.statgrad.org/" target="_blank"
            class="btn btn-success btn-block adms href">Статград ВПР</a>
        <a href="https://statgrad.org/" target="_blank"
            class="btn btn-info btn-block adms href">Статград</a>
        <a href="http://kais.irro.ru/" target="_blank" class="btn btn-light adms href">КАИС ИРРО</a>
    </div>
</div>
<div class="col-sm-4">
    <div class="h6">Системы обучения и подготовки</div>
    <div class="btn-group-vertical btn-block shadow-lg">
        <!--a href="servises.php" class="btn btn-info btn-block">Сервисы</a-->
        <a href="http://testedu.ru" target="_blank"
            class="btn btn-success btn-block href">Образовательные тесты</a>
        <a href="https://testschool.ru" target="_blank" class="btn btn-success btn-block href">Школьные
            тесты</a>
        <a href="http://kpolyakov.spb.ru/" target="_blank" class="btn btn-light btn-block href">Сайт
            К.Полякова</a>
    </div>
</div>
            </div>
        </div>
    </div>
</div>
            