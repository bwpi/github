<div class="cover-container d-flex w-100 h-100 p-3 mx-auto flex-column">
    <div class="inner">
        <nav class="navbar navbar-expand-md navbar-dark bg-transparent shadow-lg" id="nav">
            <a class="navbar-brand" href="<?=HTTP_HOST;?>"><img src="<?=HTTP_HOST;?>img/bg1.png" alt="Админка"
                    width="30em" class="icons"></a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExample03"
                aria-controls="navbarsExample03" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarsExample03">
                <ul class="navbar-nav mr-auto user">
                    <a href="http://seo.gsosh-gari.ru" target="_blank" class="btn bg-transparent">СЭО<img
                            src="<?=HTTP_HOST;?>img/logo_0.png" alt="СЭО МКОУ ГСОШ" width="30em"
                            class="icons shadow-sm"></a>
                    <a class="nav-link btn btn-transparent" target="_blank" href="http://robotlandia.ru/abc5/index.htm">
                        <font style="vertical-align: inherit;">Scratch 2</font>
                    </a>
                    <a class="nav-link btn btn-transparent" target="_blank" href="https://scratch.mit.edu">
                        <font style="vertical-align: inherit;">Scratch 3</font>
                    </a>
                    <a class="nav-link btn btn-transparent" data-toggle="modal" data-target="#calend">
                        <font style="vertical-align: inherit;">Календарь</font>
                    </a>
                    <a class="nav-link btn btn-transparent rassp1" data-toggle="modal" data-target="#ras">
                        <font style="vertical-align: inherit;">Расписание</font>
                    </a>
                </ul>
            </div>
            <div class="user_name1">
                <?= $ip;?>
            </div>

            <form class="form-horizontal search" role="form" action="https://yandex.ru/search/" role="search"
                aria-label="Поиск в интернете">
                <div class="input-group">
                    <input type="text" class="form-control" placeholder="Поиск Яндекса" autocomplete="off"
                        autocorrect="off" autocapitalize="off" spellcheck="false" aria-autocomplete="list"
                        aria-label="Запрос" id="text" maxlength="400" name="text" autofocus>
                    <div class="input-group-append">
                        <button class="btn btn-success" data-bem="{&quot;button&quot;:{}}" tabindex="-1" role="button"
                            type="submit">Поиск</button>
                    </div>
                </div>
            </form>
        </nav>
        <!-- Button trigger modal -->
        <!-- Календарь -->
        <div class="modal fade" id="calend" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
            aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content bg-dark">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body" id="cal_modal">
                        <?php include WWW . 'cal.php';?>
                    </div>
                </div>
            </div>
        </div>
        <!-- Рассписание -->
        <div class="modal fade bd-example-modal-lg" id="ras" tabindex="-1" role="dialog"
            aria-labelledby="myLargeModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-lg">
                <div class="modal-content bg-dark">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body rassp_modal">
                        <div class="spinner-border text-warning" role="status">
                            <span class="sr-only">Loading...</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="h3 m-2 text-center"><?= $main;?></div>
        <div class="row">            
            <div class="col-md">
                <div class="alert alert-white bg-transparent bg-dark shadow-lg" role="alert">Выход в интернет
                    осуществлять строго с данной страницы. Обязательно прочтите
                    <button type="button" class="btn btn-danger" data-toggle="modal" data-target="#usersModal">
                        Пользовательское соглашение
                    </button>
                    <a class="btn btn-warning" id="que_st">Опросы</a>
                </div>
            </div>
        </div>
        <div class="modal fade" id="usersModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content bg-dark">
                    <div class="modal-header">
                        <h5 class="modal-title">Правила пользования сайтом</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="text-white text-left" role="alert">
                            Перед вами стартовая станица доступа к сети интернет.<br /> 1. Менять ее в настройках
                            браузера категорически запрещено!<br /> 2. На данной странице размещаются ссылки на
                            инфомрационные системы школы, cервисы сети иинтернет образовательной
                            направленности.<br /> 3. Ссылки сгруппированы по категориям.<br /> 4. Ссылки будут
                            пополняться, категории размещаться.<br /> Предложения по совершенстованию данной
                            инфомационной страницы подавать Администратору системы.<br /> Если есть
                            собственные идеи по совершенстованию сайта - предлагайте.<br />
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-danger" data-dismiss="modal" id="sub_users">Принять
                            условия</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <form class="form-horizontal" role="form" action="https://yandex.ru/search/" role="search"
        aria-label="Поиск в интернете"
        data-bem="{&quot;suggest2-form&quot;:{},&quot;suggest2-counter&quot;:{&quot;service&quot;:&quot;morda_ru_desktop&quot;,&quot;host&quot;:&quot;//yandex.ru/clck&quot;,&quot;path&quot;:&quot;jclck&quot;,&quot;submitBySelect&quot;:true,&quot;preventSubmit&quot;:true,&quot;suggestReqID&quot;:true,&quot;params&quot;:{&quot;dtype&quot;:&quot;stred&quot;,&quot;pid&quot;:&quot;0&quot;,&quot;cid&quot;:&quot;2873&quot;}},&quot;search2&quot;:{&quot;cleanOnSubmit&quot;:false,&quot;nl&quot;:true}}">
        <div class="row">
            <div class="col-md-10">
                <input class="form-control" type="text" placeholder="Поиск Яндекса" autocomplete="off" autocorrect="off"
                    autocapitalize="off" spellcheck="false" aria-autocomplete="list" aria-label="Запрос" id="text"
                    maxlength="400" name="text" autofocus>
            </div>
            <div class="col-md-2">
                <button class="btn btn-success btn-block" data-bem="{&quot;button&quot;:{}}" tabindex="-1" role="button"
                    type="submit">Поиск</button>
            </div>
        </div>
    </form>
    <div class="row">
        <div class="col-sm-12">
            <div id="cont_ent">
                <div class="row">
                    <div class="col-sm-4">
                        <div class="h6">Обучающие ресурсы</div>
                        <div class="btn-group-vertical btn-block shadow-lg">
                            <a href="http://dnevnik.ru" target="_blank" class="btn btn-light btn-block href"><img
                                    src="https://static.dnevnik.ru/img/logotypes/logotype.png" alt="Дневник.ру"
                                    height="20em"></a>
                            <a href="http://learningapps.org" target="_blank" class="btn btn-info btn-block href"><img
                                    class="images" src="<?=HTTP_HOST;?>img/logo.png" alt="Learningapps.org"
                                    height="20em"></a>
                            <a href="http://plickers.com" target="_blank" class="btn btn-success btn-light href"><img
                                    class="images" src="<?=HTTP_HOST;?>img/logo_5.png" alt="plickers.com"
                                    height="20em"></a>
                        </div>
                    </div>
                    <div class="col-sm-4">
                        <div class="h6">Оффициальные сайты</div>
                        <div class="btn-group-vertical btn-block shadow-lg">
                            <a href="http://gsosh-gari.ru" target="_blank" class="btn btn-warning btn-block href"><img
                                    class="images" src="<?=HTTP_HOST;?>img/logo1.png" alt="Сайт школы"
                                    height="20em">Сайт МКОУ ГСОШ</a>
                            <a href="http://ege.edu.ru" target="_blank" class="btn btn-info btn-light href"><img
                                    class="images" src="<?=HTTP_HOST;?>img/logo2.png" alt="ЕГЭ 2019" height="20em"></a>
                            <a href="http://gia.edu.ru" target="_blank" class="btn btn-success btn-light href"><img
                                    class="images" src="<?=HTTP_HOST;?>img/logo3.png" alt="ОГЭ 2019" height="20em"></a>
                        </div>
                    </div>
                    <div class="col-sm-4">
                        <div class="h6">Системы обучения и подготовки</div>
                        <div class="btn-group-vertical btn-block shadow-lg">
                            <a href="http://testedu.ru" target="_blank"
                                class="btn btn-success btn-block href">Образовательные тесты</a>
                            <a href="https://testschool.ru" target="_blank"
                                class="btn btn-success btn-block href">Школьные тесты</a>
                            <a href="http://kpolyakov.spb.ru/" target="_blank" class="btn btn-light btn-block href">Сайт
                                К.Полякова</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>