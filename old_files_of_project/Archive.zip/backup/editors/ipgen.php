<?php
  $net = '10.10.0.';
  for ($i=0; $i < 100; $i++) { 
    $ip = $i;
    echo $net.$ip. '</br>';    
  };
?>




