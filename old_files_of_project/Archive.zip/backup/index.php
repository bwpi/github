<?php
error_reporting(-1);
include_once ("config.php");
include ("auth/auth.php");
include ("auth/ip.php");
?>
