<?php 
/*
Форма обратной связи может получать сообщения с любых почтовых ящиков.
Исправлена проблема кодировки при получении писем почтовым клиентом Outlook.
Вы скачали её с сайта Epic Blog https://epicblog.net Заходите на сайт снова!
ВНИМАНИЕ! Лучше всего в переменную myemail прописать почту домена, который использует сайт. А не mail.ru, gmail и тд.
*/
if(isset($_POST['submit'])){
mail("bwpi@yandex.ru", "the subject", "Привет", "From: webmaster@$SERVER_NAME", "-fwebmaster@$SERVER_NAME");
echo 'Отправлено';
}
?>
