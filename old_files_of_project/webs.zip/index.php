<?php
/*
*Включение ошибок
*/
/*ini_set('error_reporting', E_ALL);
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);*/
/*
*Константы
*/
define('FILES', 'files/');
/*
*Переменные
*/
$title = 'Расписание';
$author = 'Учитель';
$out = [];
$out_array = [];
$day_array = [];
/*
*Функции
*/
function debug($arr) {
    echo '<pre>' . print_r($arr, true) . '</pre>';
}

function loadData($file_name = '', $mode=true){
	return json_decode(file_get_contents($file_name), $mode);
}

/*function debug($arr) {
    echo '<pre>' . print_r($arr, true) . '</pre>';
}
$today = date("Y-m-d");
//include '08/index.php';
//include '09/index.php';
//include '10/index.php';
$day = ['06','01','2020'];
$today = array_reverse(explode("-", $today));

if (($today[0]===$day[0])&&($today[1]===$day[1])) {
	echo 'Поздравляю у Вас сегодня день рождения!!!';
} else {
	echo "До дня рождения еще ".($day[1]-$today[1]) ." месяцев!";
}*/

/*
*Ядро нашей программы
*/
$files = scandir(FILES);
unset($files[0], $files[1]);
$files = array_values($files);

foreach ($files as $value) {
	$name = explode('.', $value);
	if ($name[1]==='json') {		
		array_push($out, $name[0]);
	}
}

sort($out, SORT_NATURAL);

if (isset($_GET['id'])) {
	$id = FILES . $_GET['id'];
} else {
	$id = FILES . '5';
}

$schedule = loadData($id . '.json');

foreach ($schedule as $key => $value) {	
	foreach ($value as $key1 => $value1) {
		array_push($day_array, $key1);
	}
}

/*
*Подключение шаблона
*/
include 'temp.php';
?>

