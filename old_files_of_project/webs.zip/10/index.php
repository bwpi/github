<?php
//ini_set('error_reporting', E_ALL);
//ini_set('display_errors', 1);
//ini_set('display_startup_errors', 1);
$title = 'рассписание';

define('FILES', '../files/');

$scandir = scandir(FILES);
unset($scandir[0] , $scandir[1]);
$scandir = array_values($scandir);
$out = [];
foreach ($scandir as $value) {
	$name = explode('.', $value);
	if ($name[1]==='json'){
		array_push($out, $name[0]);
	}	
}
sort($out, SORT_NATURAL);

function debug($arr) {
    echo '<pre>' . print_r($arr, true) . '</pre>';
}

function fileGetContents($value='', $mode = true) {
	return json_decode(file_get_contents($value), $mode);
}

if (isset($_GET['id'])) {
	$id = FILES .  $_GET['id'];
} else {
	$id = FILES . '5';
}

$schedule = fileGetContents($id . '.json');
//debug($schedule);
$out_array = [];
$day_array = [];

foreach ($schedule as $key => $value) 
{
	array_push($out_array, $value);
	foreach ($value as $key1 => $value) {
		array_push($day_array, $key1);		
	}
}


include 'temp.php';
?>