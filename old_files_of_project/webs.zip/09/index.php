<?php
/*
*ошибки
*/
/*
ini_set('error_reporting', E_ALL);
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
*/
/*
*константы
*/
define('FILES', '../files/');
/*
*переменные
*/
$author='Алексеев';
$out = [];
$day = []; 
/*
*функции
*/
function debug($arr) {
    echo '<pre>' . print_r($arr, true) . '</pre>';
}
function tarara($value = '', $mode=true){
return json_decode(file_get_contents($value), $mode);
}
/*
*остальное
*/
$files = scandir(FILES);
unset($files[0], $files[1]);
$files = array_values($files);
foreach ($files as $value) {
	$name = explode('.', $value);
	if ($name[1] === 'json')
	{
		array_push($out, $name[0]);		
	}
}
sort($out, SORT_NATURAL);
if (isset($_GET['id'])) {
	$id = FILES . $_GET['id'];
}
else{
	$id = FILES . "5";
}
$schedule = tarara($id . '.json');
//debug($schedule);
 foreach ($schedule as $key => $value) {
 	foreach ($value as $key1 => $value1) {
 		array_push($day, $key1);
 	}
 }
 
include 'temp.php'; ?>
