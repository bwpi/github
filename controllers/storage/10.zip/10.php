
<?php
/*
* Подключение персонального контроллера
$head
$storage_views || $content
$script_file
$scripts
*/
// debug($_SERVER);
$storage_views = $controller . '/' . $view;
$head = "<style> div a {display: block;}
        .buttons {
            text-align: center;
        }
        .buttons a {
            color: #CE0808;
            background-color: rgba(255,255,255,0.5);
            border: 2px solid #CE0808;
            border-radius: 0 10px 0 10px;
            transition: 0.2s;
            display: block;
            margin: 5px;
            padding: 5px;
            width: 90%;
            font-size: 20px;
            height: 44px;
            overflow: hidden;
            word-break: break-all;
            text-decoration: none;  
            position: relative;      
        }
        .buttons a i {
            position: absolute;
            left: 15px;
            top: 10px;
        }
        .buttons a:hover {
            color: white !important;
            background-color: #CE0808;
            border-radius: 10px 0 10px 0;
            height: max-content;
        }
        .exit a {
            height: max-content;
            width: 150px;
        }
</style>";

$file_path = ROOT . '/' . str_replace('+', " ",$_SERVER[QUERY_STRING]);
if (file_exists($file_path)) {
    if(is_file($file_path)){        
        // ob_end_clean();       
        header('Content-Description: File Transfer');
        header('Content-Type: ' . mime_content_type($file_path));
        header('Content-Disposition: attachment; filename=' . basename($file_path));
        header('Content-Transfer-Encoding: binary');
        header('Content-Length: ' . filesize($file_path));
        readfile($file_path);
        exit();    
    }
} else {
    echo "Файл $file_path не существует";
}
?>


<?php

// $users = [
//  'user'=>'12345',
//  'guest'=>'54321',
//  'auth'=>'password'
// ];

// function auth($users = [], $time = 60) {
//     session_start();    
//     if ($_SESSION['auth']&&$_COOKIE['auth']) {
//         echo '<a href="?exit">Выход</a><br>';
//         return true;
//     } else {        
//         foreach ($_GET as $key => $value) {
//         if ($users[$key]) {
//                 if($users[$key] == $value){
//                     $_SESSION['auth'] = true;
//                     setcookie("auth", true, time() + $time, '/');
//                     echo '<a href="?exit">Выход</a><br>';
//                     return true;           
//                 } else {
//                     echo 'Не верный пароль - ' . $_SERVER[REMOTE_ADDR];                    
//                     exit;
//                 }
//             }
//         }
//         echo 'Отказано в доступе - ' . $_SERVER[REMOTE_ADDR];        
//         exit;
//     }    
// }
// auth($users);

$main_dir = ROOT . "/$controller/";

$files = scanRec($main_dir);

ob_start();
echo '<div class="buttons">';
setPath($files, $main_dir);
echo '</div>';
$content = ob_get_clean();

if(isset($_GET['exit'])){
    echo 'exit';
    unset($_COOKIE['auth']);
    setcookie('auth', null, -1, '/');
    session_destroy();
    header("Refresh:0");
}