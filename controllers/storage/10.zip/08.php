<?php
// debug($_SERVER);
$file_path = ROOT . '/' . str_replace('+', " ",$_SERVER[QUERY_STRING]);
if (file_exists($file_path)) {
    if(is_file($file_path)){        
        // ob_end_clean();       
        header('Content-Description: File Transfer');
        header('Content-Type: ' . mime_content_type($file_path));
        header('Content-Disposition: attachment; filename=' . basename($file_path));
        header('Content-Transfer-Encoding: binary');
        header('Content-Length: ' . filesize($file_path));
        readfile($file_path);
        exit();    
    }
} else {
    echo "Файл $file_path не существует";
}
?>


<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-F3w7mX95PdgyTmZZMECAngseQB83DfGTowi0iMjiWaeVhAn4FJkqJByhZMI3AhiU" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-/bQdsTh/da6pkI1MST/rWKFNjaCP5gBSY4sEBT38Q/9RBh9AH40zEOg7Hlq2THRZ" crossorigin="anonymous"></script>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css">
<link rel="icon" type="image/png" href="https://img.icons8.com/doodle/480/000000/puzzle--v1.png">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@5.15.4/css/fontawesome.min.css" integrity="sha384-jLKHWM3JRmfMU0A5x5AkjWkw/EYfGUAGagvnfryNV3F9VqM98XiIH7VBGVoxVSc7" crossorigin="anonymous">
<style>
    body {
        background-image: url();
    }
    .buttons {
        text-align: center;
    }
    .buttons a {
        color: #CE0808;
        background-color: rgba(255,255,255,0.5);
        border: 2px solid #CE0808;
        border-radius: 0 10px 0 10px;
        transition: 0.2s;
        display: block;
        margin: 5px;
        padding: 5px;
        width: 90%;
        font-size: 20px;
        height: 44px;
        overflow: hidden;
        word-break: break-all;
        text-decoration: none;  
        position: relative;      
    }
    .buttons a i {
        position: absolute;
        left: 15px;
        top: 10px;
    }
    .buttons a:hover {
        color: white !important;
        background-color: #CE0808;
        border-radius: 10px 0 10px 0;
        height: max-content;
    }
    .exit a {
        height: max-content;
        width: 150px;
    }
    .green {
        border-color: green !important;
        color: green !important; 
    }
    .buttons a.green:hover {        
        background-color: green;       
    }
</style>
<?php
$users = [
    'i' => 'b4b147bc522828731f1a016bfa72c073',
    'guest'=> '084e0343a0486ff05530df6c705c8bb4',
    'auth' => '1a1dc91c907325c69271ddf0c944bc72',
    'o' => 'o',
    'exit' => 'lol'
];
if(isset($_GET['exit'])){
        unset($_COOKIE['auth']);
        setcookie('auth', null, -1, '/');
        session_destroy();        
    }     
function auth($users = [], $time = 15) {
    session_start();    
    if ($_SESSION['auth']&&$_COOKIE['auth']) {        
        return true;
    } else {
        foreach ($_GET as $key => $value) {
        if ($users[$key]) {
                if($users[$key] == $value){
                    $_SESSION['auth'] = true;
                    setcookie("auth", true, time() + $time, '/');                    
                    return true;           
                } else {
                    echo 'Неправильно, попробуй еще раз! - - - - - ' . $_SERVER[REMOTE_ADDR];                    
                    exit;
                }
            }
        }
        echo 'Отказано в доступе - ' . $_SERVER[REMOTE_ADDR];        
        exit;
    }    
}
// auth($users);
// function enter($userName, $password, $info = []) {
//  if (($info[$userName] != $password)) {
//      echo 'Отказано в доступе - ' . $_SERVER[REMOTE_ADDR];
//      echo '<a href="http://' . $_SERVER['HTTP_HOST'] . '/login/">Авторизуйтесь</a>';
//      // echo '<form method="post">
//      //      <p>Куда вам: <input type="text" name="storage" /></p>
//      //          <p>Ваше имя: <input type="text" name="userName" /></p>
//      //          <p>Ваш пароль: <input type="text" name="auth" /></p>
//      //          <p><input type="submit" /></p>
//      //  </form>';
//      exit;
//  }
// }
// enter($_GET['userName'], $_GET['auth'], $users);
// function auth($password = '') {  
//     if($_GET['auth'] == $password) {
//         $_SESSION['auth'] = true;
//         setcookie("auth", true, time() + 300, '/');
//     }
//     if ($_SESSION['auth']&&$_COOKIE['auth']) {
//         return true;
//     } else {
//         if (!isset($_GET['auth'])||($_GET['auth']!=$password)) {        
//             echo 'Отказано в доступе - ' . $_SERVER[REMOTE_ADDR];
//             echo '<a href="http://' . $_SERVER['HTTP_HOST'] . '/login/">Авторизуйтесь</a>';
//             exit;
//         }
//     }
// }

// auth('00');

$main_dir = ROOT . "/$controller/";
// echo $main_dir . '<br>';
// echo "http://" . $_SERVER['HTTP_HOST'] . "/$controller";
// debug(scandir($main_dir. "/d1" ));
$files = scanRec($main_dir);



?>



<div class='buttons exit'><a href='?exit' class='btn dRed'><i class="bi bi-box-arrow-in-left"></i> Выход</a></div>
<div class="buttons">
    <?php setPath($files, $main_dir);?>
</div>